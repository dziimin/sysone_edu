package array;

public class ArrayTest2 {
	public static void main(String[] args) {
		
		//int[] s = new int[] {100,200,300};
		int[] s = {100,200,300};
		
		for(int i = 0 ; i< s.length; i++) {
			System.out.println(s[i]);
		}
	}
}
