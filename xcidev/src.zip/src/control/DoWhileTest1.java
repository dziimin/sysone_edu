package control;

public class DoWhileTest1 {
	public static void main(String[] args) {
		int i =1;
		do{
			System.out.println("SysOne");
			i++;
		}while(i<=3);
	}
}
