package control;

public class WhileTest1 {
	public static void main(String[] args) {
		int n = 1;
		while (n <= 3) {
			System.out.println(n+": sysone");
			n++; //
		}
	}
}
