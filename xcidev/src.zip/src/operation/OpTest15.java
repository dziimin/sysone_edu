package operation;

public class OpTest15 {
	public static void main(String[] args) {
		int dice  = (int)(Math.random()*6) +1; // javalang에 이미 들어있어서 import 따로안함
		// random : 0 ~ 0.999999999
		System.out.println(dice);
	}
}
