package operation;

public class OpTest11 {
	public static void main(String[] args) {
		int a = 10;
		int b = 5;
		
		System.out.println(a> b ? a: b);
	}
}
