package operation;

public class OpTest16 {
	public static void main(String[] args) {
		//int rand = (int)(Math.random()*11) +4;
		
		// 4 ~ 15 만 출력
		System.out.println((int)(Math.random()*12) +4);
		System.out.println((int)(Math.random()*12) +4);
		System.out.println((int)(Math.random()*12) +4);
		System.out.println((int)(Math.random()*12) +4);
		System.out.println((int)(Math.random()*12) +4);
		System.out.println((int)(Math.random()*12) +4);
		System.out.println((int)(Math.random()*12) +4);
		System.out.println((int)(Math.random()*12) +4);
		System.out.println((int)(Math.random()*12) +4);
		System.out.println((int)(Math.random()*12) +4);
		System.out.println((int)(Math.random()*12) +4);
		System.out.println((int)(Math.random()*12) +4);
		System.out.println((int)(Math.random()*12) +4);
		System.out.println((int)(Math.random()*12) +4);
		System.out.println((int)(Math.random()*12) +4);
		System.out.println((int)(Math.random()*12) +4);
		
		System.out.println();
		
		// 600, 700, ~ 2300 만 출력
		System.out.println(((int)(Math.random()*18) + 6)*100);
		System.out.println(((int)(Math.random()*18) + 6)*100);
		System.out.println(((int)(Math.random()*18) + 6)*100);
		System.out.println(((int)(Math.random()*18) + 6)*100);
		System.out.println(((int)(Math.random()*18) + 6)*100);
		System.out.println(((int)(Math.random()*18) + 6)*100);
		System.out.println(((int)(Math.random()*18) + 6)*100);
		System.out.println(((int)(Math.random()*18) + 6)*100);
		System.out.println(((int)(Math.random()*18) + 6)*100);
		System.out.println(((int)(Math.random()*18) + 6)*100);
		System.out.println(((int)(Math.random()*18) + 6)*100);
		System.out.println(((int)(Math.random()*18) + 6)*100);
		System.out.println(((int)(Math.random()*18) + 6)*100);
		System.out.println(((int)(Math.random()*18) + 6)*100);
		System.out.println(((int)(Math.random()*18) + 6)*100);
		
		
		
		
	}
}
