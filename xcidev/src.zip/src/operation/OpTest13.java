package operation;

public class OpTest13 {
	public static void main(String[] args) {
		int a = -5;

		System.out.println(a > 0 ? " 양수" : 
							a < 0 ? "음수" : "zero");
	}
}
