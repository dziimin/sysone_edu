package operation;

public class OpTest7 {
	public static void main(String[] args) {
		int a = 10;
		
		int b = a--;
		
		System.out.println(b);
		System.out.println(a);		
	}
}
