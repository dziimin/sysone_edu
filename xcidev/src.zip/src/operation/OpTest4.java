package operation;

public class OpTest4 {
	public static void main(String[] args) {
		int a = 10;
		
		a = a+1; // a++ ++a
		
		System.out.println(a);

		a++;
		System.out.println(a);
		
		--a;
		System.out.println(a);
		
		
	}
}
