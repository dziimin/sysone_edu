package basic;

public class Hello2 {
	public static void main(String[] args) {
		System.out.println("Hello Java");
		System.out.print("Hello Spring");
		System.out.print("Hello Oracle");
		
		// ctrl + shift + f : 정렬
		// ctrl + / :  //주석처리
		// ctrl + shift + / : /* 주석처리 */ , 해제시 ctrl + shift + \
		
	}
}