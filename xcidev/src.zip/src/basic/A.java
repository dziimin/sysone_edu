package basic;

public class A {

}
//public classB 에러, public은 파일당 한개만
class B{
	
}