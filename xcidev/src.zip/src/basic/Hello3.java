package basic;

public class Hello3 {
	public static void main(String[] args) {
		System.out.println("Hello Java");
		System.out.print("Hello Spring");
		System.out.print("Hello Web");
	}
}