package stringclass;

public class StringTest1 {
	public static void main(String[] args) {
		System.out.println("Hello world");
		String str = new String("문자열");
		String str2 = "문자열";
	}
}
